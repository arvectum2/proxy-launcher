package main
import ("encoding/binary";"github.com/amnezia-vpn/amneziawg-go/v3/tun";"net/netip";"os";"sync")
const bridgeMTU = 1280
const bridgeDepth = 32
const bridgeFailure = -1
const bridgeFull = -2

type packetBridgeTUN struct {
	send, receive chan []byte
	done          chan struct{}
	events        chan tun.Event
	mu            sync.Mutex
	closed        bool
}

var _ tun.Device = (*packetBridgeTUN)(nil)

func newPacketBridgeTUN() *packetBridgeTUN {
	t := &packetBridgeTUN{send: make(chan []byte, bridgeDepth), receive: make(chan []byte, bridgeDepth), done: make(chan struct{}), events: make(chan tun.Event, 1)}
	// Explicit device.Up controls lifecycle; no implicit asynchronous start.
	return t
}
func validBridgePacket(p []byte) bool {
	if len(p) < 20 || len(p) > bridgeMTU {
		return false
	}
	switch p[0] >> 4 {
	case 4:
		h := int(p[0]&15) * 4
		return h >= 20 && h <= len(p) && int(binary.BigEndian.Uint16(p[2:4])) == len(p)
	case 6:
		return len(p) >= 40 && int(binary.BigEndian.Uint16(p[4:6]))+40 == len(p)
	default:
		return false
	}
}
func (t *packetBridgeTUN) File() *os.File           { return nil }
func (t *packetBridgeTUN) MTU() (int, error)        { return bridgeMTU, nil }
func (t *packetBridgeTUN) Name() (string, error)    { return "apl-awg-packet-bridge", nil }
func (t *packetBridgeTUN) Events() <-chan tun.Event { return t.events }
func (t *packetBridgeTUN) BatchSize() int           { return 1 }
func (t *packetBridgeTUN) Close() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if !t.closed {
		t.closed = true
		close(t.done)
		close(t.events)
	}
	return nil
}
func (t *packetBridgeTUN) push(p []byte) int {
	if !validBridgePacket(p) {
		return bridgeFailure
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.closed {
		return bridgeFailure
	}
	select {
	case t.send <- append([]byte(nil), p...):
		return len(p)
	default:
		return bridgeFull
	}
}

// Nonblocking receive. Caller supplies MTU-sized buffer; no truncation.
func (t *packetBridgeTUN) pull(buf []byte) int {
	if len(buf) < bridgeMTU {
		return bridgeFailure
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.closed {
		return bridgeFailure
	}
	select {
	case p := <-t.receive:
		return copy(buf, p)
	default:
		return 0
	}
}
func (t *packetBridgeTUN) Read(bufs [][]byte, sizes []int, offset int) (int, error) {
	if len(bufs) == 0 || len(sizes) == 0 || offset < 0 || offset > len(bufs[0]) {
		return 0, os.ErrInvalid
	}
	select {
	case <-t.done:
		return 0, os.ErrClosed
	case p := <-t.send:
		t.mu.Lock()
		defer t.mu.Unlock()
		if t.closed {
			return 0, os.ErrClosed
		}
		if len(bufs[0])-offset < len(p) {
			return 0, os.ErrInvalid
		}
		sizes[0] = copy(bufs[0][offset:], p)
		return 1, nil
	}
}
func (t *packetBridgeTUN) Write(bufs [][]byte, offset int) (int, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.closed {
		return 0, os.ErrClosed
	}
	for i, b := range bufs {
		if offset < 0 || offset > len(b) || !validBridgePacket(b[offset:]) {
			return i, os.ErrInvalid
		}
		select {
		case t.receive <- append([]byte(nil), b[offset:]...):
		default: /* bounded drop, no fallback */
		}
	}
	return len(bufs), nil
}

type endpoint struct{ netip.AddrPort }

func (e endpoint) ClearSrc()           {}
func (e endpoint) SrcToString() string { return "" }
func (e endpoint) DstToString() string { return e.String() }
func (e endpoint) DstToBytes() []byte  { b, _ := e.MarshalBinary(); return b }
func (e endpoint) DstIP() netip.Addr   { return e.Addr() }
func (e endpoint) SrcIP() netip.Addr   { return netip.Addr{} }

// Private bind implementing upstream conn.Bind on actual localhost UDP.
// Reject every endpoint except 127.0.0.1; no external route.
type scopedEndpoint struct{ netip.AddrPort }

func (e scopedEndpoint) ClearSrc()           {}
func (e scopedEndpoint) SrcToString() string { return "" }
func (e scopedEndpoint) DstToString() string { return e.String() }
func (e scopedEndpoint) DstToBytes() []byte  { b, _ := e.MarshalBinary(); return b }
func (e scopedEndpoint) DstIP() netip.Addr   { return e.Addr() }
func (e scopedEndpoint) SrcIP() netip.Addr   { return netip.Addr{} }

